#mypackage
This package was created as an example of how to create my first package

## building this package locally
'python setup.py sdist'

## installing this package from Github
pip install git +'https://github.com/MichaelOmosebi/myfirstpackage.git'

## updating this package from Github
pip install -- update git +'https://github.com/MichaelOmosebi/myfirstpackage.git'
